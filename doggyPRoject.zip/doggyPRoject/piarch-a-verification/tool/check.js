/**
 * Created by doga on 28/12/15.
 */
var nano = require('nanomsg'),
    redis = require('redis'),
    config = require('../resources/config'),
    req = nano.socket('req');


req.connect('tcp://127.0.0.1:5608');

req.on('data', function (buf) {
    console.log(buf.toString());
});



var redisCli = redis.createClient(config.redis.port, config.redis.host, {no_ready_check: true});

redisCli.on("error", function (err) {

});

redisCli.select(config.redis.db, function (err, res) {
    if (err)  {
    }
});



setTimeout(() => {
    req.send('jwt eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlbXJlQWNheSIsImlzcyI6InBpYXJjaF9hIiwiaWF0IjoxNTM2ODYwMjA3LCJleHAiOjE1MzY4OTYyMDd9.b3A17ed5MxwBYQ6rsdquUvOrxUT13_JIX8vfgG-L_9pFUHz-GDJueBQh1mkj46RaCzOKXwGRzgGg6ysXti-qex9QxfhvAEvDVtb9hpgDjNOCFThbcWzBwK1YKd1apUyMp4bLM-zm6UjVP1QfDMUbqCnc5YM0YMosqdrtHLqFzFO47VI_6l0MEEg8lJTA4j1zeJZkLnzMVpAZLIlAILPqZWAVccdbotGGd7TrtJrtuoKLVTkSTP4W_24AaU0x4udCpZb-qiW6gTUUXZxXCq0qT1-evwTnhApWQX1vFWjqyCvT7pPmSYU7GIre5wVXk8RgiCpgbYZq-vHwCMM9Vifajg')
}, 0);



setTimeout(() => {
    req.send('jwt eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJlbXJlQWNheSIsImlzcyI6InBpYXJjaF9hIiwiaWF0IjoxNTM2ODYyMDYzLCJleHAiOjE1MzY4OTgwNjN9.IqfJEkZbFNdNjWOcD0xvFsaQqEnv_cWpMDDMbV_2NeLgl4AFWQ9gD0xdDsqyUqaV-Z2lXY-xhpe5A_ak1QaUFPz4KCWhF_TLHxn5ls1HXflvIqID-cuAyfuF6stjfwCv0KXGOvhdldfGc5RqwFVc7C9NBDC1EC_ghg-NcmiswxaiyPmxjEqMJFIBVhtSgTF9OGZN8Px0ezk1IvTaXDd1mXtSrayB7DycSXzf8UfS8RW63sDF4DwZ2xUqsWIRnTaeK4bO0tzvD2Cep5BP3Rkw2Lsk_XMndNVGwZNApCv4iMacD6f8a24csAP-Jbf94LwEruOf9qsU6SZwBk_CSOJkDA')
}, 100);
